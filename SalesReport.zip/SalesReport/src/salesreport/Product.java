package salesreport;

public class Product implements IProduct {

    // Single-dimensional array
    private String[] productNames = {
        "Cozy Nights Monarch mattress",
        "Restonic Barbados mattress",
        "Sealy Phuket mattress"
    };

    // Two-dimensional array
    private int[][] sales;

    // Constructor
    public Product(int[][] sales) {
        this.sales = sales;
    }

    // Calculate total products sold
    @Override
    public int GetTotalProductsSold() {

        int total = 0;

        for (int i = 0; i < sales.length; i++) {

            for (int j = 0; j < sales[i].length; j++) {

                total += sales[i][j];

            }
        }

        return total;
    }

    // Calculate average products sold
    @Override
    public double GetAverageProductSold() {

        int total = GetTotalProductsSold();

        return (double) total / 9;
    }

    // Determine most popular product
    @Override
    public String GetMostPopularProduct() {

        int highestSales = -1;
        int popularIndex = 0;

        for (int i = 0; i < sales.length; i++) {

            int productTotal = 0;

            for (int j = 0; j < sales[i].length; j++) {

                productTotal += sales[i][j];

            }

            if (productTotal > highestSales) {

                highestSales = productTotal;
                popularIndex = i;

            }
        }

        return productNames[popularIndex]
                + " (" + highestSales + ")";
    }

}