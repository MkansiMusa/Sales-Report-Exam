package salesreport;

public class PrintProduct {

    private Product product;

    // Constructor
    public PrintProduct(Product product) {
        this.product = product;
    }

    // Print total sales
    public void PrintTotalProductSales() {

        System.out.println(
            "TOTAL PRODUCT SALES: "
            + product.GetTotalProductsSold()
        );
    }

    // Print average sales
    public void PrintAverageProductSales() {

        System.out.println(
            "AVERAGE PRODUCT SALES: "
            + product.GetAverageProductSold()
        );
    }

    // Print most popular product
    public void PrintMostPopularProduct() {

        System.out.println(
            "MOST POPULAR PRODUCT: "
            + product.GetMostPopularProduct()
        );
    }

    // Print complete report
    public void PrintReport() {

        System.out.println("\nPRODUCT SALES REPORT - 2026");

        System.out.println(
            "****************************************"
        );

        PrintTotalProductSales();

        PrintAverageProductSales();

        PrintMostPopularProduct();
    }

}