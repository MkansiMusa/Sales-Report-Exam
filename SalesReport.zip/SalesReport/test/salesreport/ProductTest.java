package salesreport;

import org.junit.Test;
import static org.junit.Assert.*;

public class ProductTest {

    @Test
    public void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {

        // Arrange: Create sample sales data
        int[][] sales = {
            {25, 18, 20},
            {15, 10, 12},
            {18, 15, 20}
        };

        // Act: Create Product object
        Product product = new Product(sales);

        int result = product.GetTotalProductsSold();

        // Assert: Check the expected result
        assertEquals(153, result);
    }
}